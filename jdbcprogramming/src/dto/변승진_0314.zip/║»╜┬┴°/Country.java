package dto;

import lombok.Data;

@Data
public class Country {
	private String countryId;
	private String countryName;
	private int regionId;
}
