package dto;

import lombok.Data;

@Data
public class Region {
	private int regionId;
	private String regionName;
}
